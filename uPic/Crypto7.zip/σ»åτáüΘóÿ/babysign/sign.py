import hashlib
import ecdsa
from Crypto.Util.number import *
import random
import os

# flag = b"xxx"
#
# assert flag.startswith(b'DASCTF{') and flag.endswith(b'}')
# assert len(flag) == 40
flag = '0'*40
def init():
    """
    initiation
    """
    global pub_key, priv_key, order, base,secret
    gen = ecdsa.NIST256p.generator
    order = gen.order()
    secret = bytes_to_long(flag[7:-1])
    
    pub_key = ecdsa.ecdsa.Public_key(gen, gen * secret)
    priv_key = ecdsa.ecdsa.Private_key(pub_key, secret)


def sign(msg, nonce):
    """
    sign msg
    """
    msg = int(hashlib.sha256(msg).hexdigest(), 16)
    
    sign = priv_key.sign(msg, nonce)
    print("R:", hex(sign.r)[2:])
    print("S:", hex(sign.s)[2:])

init()
# nonce = random.getrandbits(order.bit_length())
# sign(b'welcome to ecdsa', nonce)
# print(nonce)

'''
R: 7b35712a50d463ac5acf7af1675b4b63ba0da23b6452023afddd58d4891ef6e5
S: a452fc44cc36fa6964d1b4f47392ff0a91350cfd58f11a4645c084d56e387e5c
nonce = 57872441580840888721108499129165088876046881204464784483281653404168342111855
'''